<script>
    export let id
</script>


<section {id}>
<slot>
</slot>
</section>