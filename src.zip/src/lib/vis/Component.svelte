<script>
  import { onMount } from 'svelte'
  //import {dims} from '$lib/backgroud_dimensions'   
  export let height=1000, width=1000 , count=0, index=0, offset=0, progress=0, family="", component="", animation=""
  import { step } from '$lib/step.js'
  import { tracker } from '$lib/tracker.js'  
  import {story_json} from "$lib/story"
  import Animated_charts from '$lib/vis/animated_charts/src/App.svelte'
  let story =$story_json
console.log("STORY",story)
  //$: $dims && height=$dims.h, width=$dims.w

    function updateStep(stp){
      tracker.set(stp)
        return $tracker
    }

    function getStep(){
      return $tracker
    }

</script>

<div class="container" bind:clientHeight={height} bind:clientWidth={width} family={family} component={component}>

{#if height}
  <svg {height} {width} {count} {index} {offset} {progress} {animation}>

  <rect
      x="2"
      y="2"
      width={width -4}
      height={height -4}
      stroke-width="5"
      stroke="black"
      stroke-dasharray="50,50"
      fill="lightgrey" />
    <text x="200" y="200">height: {height}</text>
    <text x="200" y="250">width: {width}</text>
    <text x="200" y="300">count: {count || 0}</text>
    <text x="200" y="350">index: {index || 0}</text>
    <text x="200" y="400">offset: {offset || 0}</text>
    <text x="200" y="450">progress: {progress || 0}</text>
    <text x="200" y="500">family: {family}</text> 
    <text x="200" y="550">component: {component}</text>

    {#if animation}
    <text x="200" y="600">animation: { updateStep(animation.section.actions['data-id'])}</text>
    <text x="200" y="650">step: {getStep(animation.section.actions['data-id'])}</text>
    <text x="200" y="700">step_change:{$tracker}</text> 
    {/if}  
 {#if animation}
  <!--<slot step={getStep(animation.section.actions['data-id'])}></slot>-->
  <svelte:component
  this={Animated_charts}
  {progress}
  {offset}
  {index}
  {count}
  family={family}
  component={component}    
  animation={updateStep(animation.section.actions['data-id'])} />
  {/if}

  
  </svg>
{/if}
</div>

<style>

    .container{
        width:100%;
        height:100vh;
    }

</style>