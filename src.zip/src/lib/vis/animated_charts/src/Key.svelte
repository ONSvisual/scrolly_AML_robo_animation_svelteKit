<script>
import { interpolateViridis } from 'd3-scale-chromatic'
export let percent, key, uk, place, max, min, step
let arr=Array.from({length: max-min+1}, (_, i) => i + min).reverse();
let range=max-min
let place_position=(max-place)/range
let uk_position=(max-uk)/range

</script>

<g transform=" scale(0.5) translate(0,-25)">
<rect x=0 y=25 width=350 height=600 fill=white></rect>
<text x=150 y={600} text-anchor=middle  font-size=24pt fill=grey>{key}</text>    
{#each arr as clr,i}
<rect width=50 height={500/arr.length} x=100 y={50 + (500/arr.length) * i} fill={interpolateViridis(i/(arr.length-1))} />
{#if clr%10==0  || i==0 || i==arr.length-1}<text x=90 y={260 + ((500/arr.length) * i)} fill=grey text-anchor=end>{clr}{percent?"%":""}</text>{/if}
{/each}
<line x1={100} x2={180} y1={50 + (500 * place_position)} y2={50+ (place_position*(500))} stroke=darkblue stroke-width=8 stroke-linecap="round" ></line>
<text x=160 y={40 + (place_position*(500))} fill=darkblue font-size=24pt>here</text>
{#if step==1}<line x1={100} x2={180} y1={50 + (uk_position*(500))} y2={50 + (uk_position*(500))} stroke=darkred stroke-width=8 stroke-linecap="round" ></line>
<text x=160 y={40 + (uk_position*(500))} fill=darkred font-size=24pt>average</text>{/if}
<text x=160 y={60} fill=grey font-size=24pt>Greatest</text>
<text x=160 y={90} fill=grey font-size=24pt>increase</text>
<text x=160 y={525} fill=grey font-size=24pt>Greatest</text>
<text x=160 y={555} fill=grey font-size=24pt>fall</text>
</g>

<style>
    #key{
        position:fixed;
        right: 95vh;
    }
</style>