<script>
  import { onMount } from 'svelte'
	import {zm} from "$lib/zm"
  import {step} from '$lib/step'  
  import { all_data } from '$lib/stores.js';
  import Key from './Key.svelte'
  export let viewBox = '0 0 300 150', height=1000, width=1000
	export let svg,x,y,k

</script>

<svg id="canvas" viewBox={viewBox} height={height} width={width} bind:this={svg} zm={$zm}>

  <g transform="translate({$x}, {$y}) scale({$k})" id="zoomable">
    <slot></slot>
  </g>
  <Key percent={true} key='percentage growth' uk=7.9 place={$all_data.LA.PC_CHANGE.FROM01TO11} max=30 min={-5} step={$step}></Key>  
</svg>
<style>
  #canvas {
position: absolute;
right:0;
height:100vh;
width:100vh;
  }
</style>