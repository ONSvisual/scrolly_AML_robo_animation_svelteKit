<script>

export let	x_origin,
						y_origin,
						x_offset = 0,
						y_offset= 0,
						x_length = width,
						y_length = height,
						hoz_bar=[y_labels.map(e=>e.length)],
						vert_bar=[],//x_labels.map(e=>e.length),
						labelRotation=0,
						x_zero=0,
						y_zero=0,
						xTicks=true,
						yTicks=true,
						xAxis=1,
						yAxis=1,
						verticalStrokes=false,
						horizontalStrokes=true
	
</script>


{#each Array(50) as item,i}

<!--verticals -->
  <g transform="translate({$x_origin + ($x_offset * (i-25)) },0 )">
		<line x1=0  x2=0 y1=5000 y2=-5000 stroke={i==25?"purple":"lightblue"}/>
		</g>

<!--horizontals -->
  <g transform="translate({$x_origin},
{($y_origin) - ($y_offset * (i-25))} )">
		<line x1=-5000  x2=2000 y1=-0 y2=0 stroke={i==25?"purple":"lightblue"}/>
  </g>
{/each}
<style>
	line{vector-effect: non-scaling-stroke;}
</style>