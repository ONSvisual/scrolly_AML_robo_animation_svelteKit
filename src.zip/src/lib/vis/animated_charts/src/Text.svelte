<script>
	import {zm} from '$lib/zm'
	export let d,centroid,fill,fillOpacity,title,mouseover,mouseout,value,pop,metric,selected,area_cd,label_opacity,zoom,x,y,k
</script>


<text class="titles" x={centroid[0]} y={centroid[1]} text-anchor=middle font-size={15/$k} opacity={$label_opacity} style="pointer-events: none;" id={selected?"selectedText":null}>
	{$title}
</text>